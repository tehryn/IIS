<?php
	echo '
		<head>
			<meta charset="UTF-8">
			<title>Sunny Night</title>
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" href="css/style.css">
			<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>

		</head>
	';
?>